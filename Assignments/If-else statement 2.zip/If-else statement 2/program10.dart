void main(){

  int Percentage = 60;

  double cgpa = 8.67;

  if(Percentage >=70 && cgpa >= 7){

    print("you are eligible for placement");
  }else{

    print("you are not eligible for placement");
  }
}