void main(){

  int numOfPerson = 4;

  if(numOfPerson <= 8){

    print("you can enter lift");
  }
  else{

    print("you can't enter lift");
  }
}