void main(){

  String vehicle = "bike";

  if(vehicle == "bike"){

    print("go to parking 2");
  }
  else if(vehicle == "scooter"){

    print("go to parking 1");
  }
}