void main(){

  int marks = 76;

  if(marks>=0 && marks<=25){

    print("grade D");
  }
  else if(marks>25 && marks<=50){

    print("grade c");
  }
  else if(marks>50 && marks<=75){

    print("grade B");
  }
  else if(marks>75 && marks<=100){

    print("grade A");
  }
}