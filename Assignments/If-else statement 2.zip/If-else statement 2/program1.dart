void main(){

  int ramSize = 4;

  if(ramSize ==4){

    print("can't run the project");
  }
  else if(ramSize ==8){

    print("can run the flutter project");
  }
}