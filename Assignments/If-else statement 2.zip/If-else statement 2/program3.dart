void main(){

  int x = 45;

  if(x>=30 && x<=50){

    print("number is correct in range $x");
  }
  else{

    print("invalid number");
  }
}