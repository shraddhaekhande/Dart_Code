void main(){

  int x = 18;

  if(x%3==2){

    print("reminder is equal to 2");
  }
  else if(x%3<2){

    print("reminder is less than 2");
  }
}