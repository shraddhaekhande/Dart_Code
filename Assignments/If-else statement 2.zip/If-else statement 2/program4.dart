void main(){

  int num = 30;

  if(num>=16 && num%2==0){

    print("correct number");
  }
  else{

    print("incorrect number");
  }
}